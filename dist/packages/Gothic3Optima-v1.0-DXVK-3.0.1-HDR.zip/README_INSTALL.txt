========================================================================
GOTHIC 3 OPTIMA - DXVK 3.0.1 HDR EDITION
========================================================================
[RU] Описание:
Версия DXVK 3.0.1 с выводом HDR. Используйте при наличии монитора или ТВ
с поддержкой HDR и включенном режиме HDR в параметрах Windows.

[EN] Description:
DXVK 3.0.1 with HDR output. Use if you have an HDR-capable monitor and Windows HDR enabled.

УСТАНОВКА / INSTALLATION:
1. Скопируйте все файлы из этого архива (dinput8.dll, d3d9.dll, dxgi.dll, dxvk.conf)
   в корневую папку Gothic 3 (где находится Gothic3.exe).
2. Убедитесь, что в Windows включен HDR (Параметры -> Дисплей -> HDR: Вкл).
3. Запустите Gothic 3 через Steam, GOG или Gothic3.exe напрямую.
========================================================================
