========================================================================
GOTHIC 3 OPTIMA - DXVK 2.4.1 STABLE EDITION (RECOMMENDED)
========================================================================
[RU] Описание:
Рекомендованная стабильная версия. Отлично подходит для видеокарт AMD
Polaris (RX 400/500), Vega, RDNA, а также NVIDIA GTX 10xx, RTX 20xx / 30xx / 40xx.

[EN] Description:
Stable version. Recommended for AMD Polaris/GCN & NVIDIA Pascal/Turing/Ampere.

УСТАНОВКА / INSTALLATION:
1. Скопируйте все файлы из этого архива (dinput8.dll, d3d9.dll, dxgi.dll, dxvk.conf)
   в корневую папку Gothic 3 (где находится Gothic3.exe).
2. Запустите Gothic 3 через Steam, GOG или Gothic3.exe напрямую.
========================================================================
